import * as THREE from '../libs/three.module.js';
import { ThreeBSP } from '../libs/ThreeBSP.js'

class Comecoco extends THREE.Object3D {
	constructor (gui, titleGui){
		super();
		this.createGUI(gui, titleGui);

		// CREACION DE OBJETOS
		this.cajaPrueba = new THREE.Mesh(
			new THREE.SphereBufferGeometry(1, 15, 15),
			new THREE.MeshPhongMaterial({color: 0xffff00})
		);

		this.add(this.cajaPrueba);

		this.cabeza = this.createCabeza();
		this.add(this.cabeza);

		// CREACION DE ANIMACIONES
		this.incremento = 0.01;
		this.decrementando = false;

		// CREACION DE TRANSFORMACIONES ELEMENTALES
		this.cajaPrueba.position.y = this.cajaPrueba.geometry.parameters.radius;
		this.cabeza.position.y = 10;
	}

	createCabeza() {
		var cabeza = new THREE.Object3D();
		this.parteArriba = this.createCabezaArriba();
		this.mandibula = this.createParteAbajo();

		cabeza.add(this.parteArriba);
		cabeza.add(this.mandibula);

		return cabeza;

	}

	createCabezaArriba() {
		var cabeza = new THREE.SphereGeometry(3, 15, 15);
		var caja = new THREE.BoxGeometry(6, 6, 6);
		var ojos = new THREE.CylinderGeometry(0.2, 0.2, 8);

		ojos.rotateZ(1.5708);
		ojos.translate(0, 1.5, 1.5);

		cabeza.translate(0, 0, 0);
		caja.translate(0, -3, 0);

		var material = new THREE.MeshPhongMaterial({color: 0xffff00});
		// this.add(new THREE.Mesh(cabeza, material));
		// this.add(new THREE.Mesh(caja, material));
		// this.add(new THREE.Mesh(ojos, material));

		var cabezaBSP = new ThreeBSP(cabeza);
		var cajaBSP = new ThreeBSP(caja);
		var ojosBSP = new ThreeBSP(ojos);

		cabezaBSP = cabezaBSP.subtract(cajaBSP);
		cabezaBSP = cabezaBSP.subtract(ojosBSP);

		var geometry = cabezaBSP.toGeometry();
		var bufferGeometry = new THREE.BufferGeometry().fromGeometry(geometry);
		var final = new THREE.Mesh(bufferGeometry, material);

		return final;
	}

	createParteAbajo(){
		var cabeza = new THREE.SphereGeometry(3, 15, 15);
		var caja = new THREE.BoxGeometry(6, 6, 6);

		cabeza.translate(0, 0, 0);
		caja.translate(0, 3, 0);

		var material = new THREE.MeshPhongMaterial({color: 0xffff00});
		// this.add(new THREE.Mesh(cabeza, material));
		// this.add(new THREE.Mesh(caja, material));
		// this.add(new THREE.Mesh(ojos, material));

		var cabezaBSP = new ThreeBSP(cabeza);
		var cajaBSP = new ThreeBSP(caja);

		cabezaBSP = cabezaBSP.subtract(cajaBSP);

		var geometry = cabezaBSP.toGeometry();
		var bufferGeometry = new THREE.BufferGeometry().fromGeometry(geometry);
		var final = new THREE.Mesh(bufferGeometry, material);

		return final;
	}

	createGUI(gui, titleGui){
		// CREACION DE GUI
		this.guiControls = new function (){
			// variables que queramos toquetear
			this.incrementoRotacion = 0;
			this.posX = 0;
			this.posZ = 0;
			this.posY = 0;
		}

		var folder = gui.addFolder(titleGui);
		folder.add(this.guiControls, 'incrementoRotacion', 0, 1, 0.01).name("Velocidad rotación: ").listen();
		folder.add(this.guiControls, 'posX', -10, 10, 1).name("Posición en x: ").listen();
		folder.add(this.guiControls, 'posZ', -10, 10, 1).name("Posición en Z: ").listen();
		folder.add(this.guiControls, 'posY', -10, 10, 1).name("Posición en Y: ").listen();
	}

	update(){
		// CREACION DE UPDATES
		// this.rotation.y += this.guiControls.incrementoRotacion;
		this.position.x = this.guiControls.posX;
		this.position.z = this.guiControls.posZ;
		this.position.y = this.guiControls.posY;

		this.mandibula.rotation.x += this.incremento;
		if (!this.decrementando && this.mandibula.rotation.x  > 0.7) {
			this.incremento *= -1;
			this.decrementando = true;
		}

		if (this.mandibula.rotation.x < 0.1 && this.decrementando){
			this.incremento *= -1;
			this.decrementando = false;
		}

	}
};


export { Comecoco };
